import React from 'react';
import './DescriptionBox.css';

const DescriptionBox = () => {
    return (
        <div className='descriptionbox'>
            <div className="descriptionbox-navigator">
                <div className="descriptionbox-nav-box">Description</div>
                <div className="descriptionbox-nav-box fade">Reviews</div>
            </div>
            <div className="descriptionbox-description">
                <p>"Experience culinary perfection with our catering services. From elegant weddings to corporate events, our expert chefs curate delectable dishes using the finest ingredients. Elevate your next gathering with our exceptional service and unforgettable flavors."</p>
                <p>"Experience culinary perfection with our catering services. From elegant weddings to corporate events, our expert chefs curate delectable dishes using the finest ingredients. Elevate your next gathering with our exceptional service and unforgettable flavors."</p>
            </div>
        </div>
    );
}

export default DescriptionBox;
