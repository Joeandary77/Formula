import React, { useContext, useRef, useState, useEffect } from 'react';
import './Navbar.css';
import logo from '../Assets/logo.png';
import cart_icon from '../Assets/cart_icon.jpg';
import { Link } from 'react-router-dom';
import { ShopContext } from '../../Context/ShopContext';
import nav_dropdown from '../Assets/dropdown_icon.png';


const Navbar = () => { 
    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://www.chatbase.co/embed.min.js';
        script.async = true;
        script.setAttribute('chatbotId', 'iXPfP8g53aJDt2_zgyRo5');
        script.setAttribute('domain', 'www.chatbase.co');
        document.body.appendChild(script);

        return () => {
            document.body.removeChild(script);
        };
    }, []);

    const [menu, setMenu] = useState("shop");
    const {getTotalCartItems} = useContext(ShopContext);
    const menuRef = useRef();

    const dropdown_toggle = (e) =>{
        menuRef.current.classList.toggle('nav-menu-visible');
        e.target.classList.toggle('open');

    }

    return (
        <div className='navbar' style={{ display: 'flex', alignItems: 'center' }}>
            <div className="nav-logo">
                <img src={logo} alt="" style={{ width: '150px', height: '60px' }} />
            </div>
            <img className='nav-dropdown' onClick={dropdown_toggle} src={nav_dropdown} alt="" />
            
            <ul ref={menuRef} className="nav-menu" style={{ display: 'flex', listStyleType: 'none', margin: 0, padding: 0, marginRight: '20px' }}>
                <li onClick={() => setMenu("shop")}>
                    <Link to='/'>Home</Link> {menu === "shop" ? <hr/> : <></>}
                </li>
                <li onClick={() => setMenu("f&b")}>
                    <Link to='/f&b'>F&B</Link> {menu === "f&b" ? <hr/> : <></>}
                </li>
                <li onClick={() => setMenu("services")}>
                    <Link to='/services'>Services</Link> {menu === "services" ? <hr/> : <></>}
                </li>
                <li onClick={() => setMenu("decorations")}>
                    <Link to='/decorations'>Decorations</Link> {menu === "decorations" ? <hr/> : <></>}
                </li>
            </ul>

            <div className="nav-login-cart">
                {localStorage.getItem('auth-token')? <button onClick={()=>{localStorage.removeItem('auth-token');window.location.replace('/')}}>Logout</button>
                :<Link to='/login'><button>Login</button></Link>}
                
                
                <div className="cart-icon-container">
                    <Link to='/cart'>
                        <img src={cart_icon} alt="Cart" style={{ width: '30px', height: '30px' }} />
                    </Link>
                    <div className="cart-count">{getTotalCartItems()}</div>
                </div>
            </div>
            
            
        </div>
    );
};

export default Navbar;
