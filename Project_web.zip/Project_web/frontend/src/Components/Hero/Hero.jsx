import React from 'react';
import './Hero.css';
import hand_icon from '../Assets/hand_icon.png';
import arrow_icon from '../Assets/arrow_icon.jpg';
import hero_image from '../Assets/hero_image.png';

const Hero = () => {
    return (
        <div className='hero'>
            <div className="hero-left">
                <h2>New Arrivals only</h2>
                <div className="hand-icon">
                    <p style={{ fontSize: '66px' }}>New</p> 
                    <img src={hand_icon} alt="Hand" style={{ width: '66px' }} />
                </div>
                <p style={{ fontSize: '66px' }}>Formula</p>
                <p style={{ fontSize: '66px' }}>For Everyone</p>
                <div className="hero-latest-btn">
                    <div>
                        Latest Formula
                        <img src={arrow_icon} alt="Arrow" style={{ width: '20px' }} />
                    </div>
                </div>
            </div>
            <div className="hero-right">
                <img src={hero_image} alt="Hero" />
            </div>
        </div>
    );
}

export default Hero;
