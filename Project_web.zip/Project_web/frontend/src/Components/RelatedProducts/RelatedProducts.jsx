import React, { useEffect, useState } from 'react';
import './RelatedProducts.css';
import all_product from '../Assets/all_product';
import Item from '../Item/Item';

const RelatedProducts = () => {
    const [shuffledProducts, setShuffledProducts] = useState([]);

    useEffect(() => {
        // Shuffle function to shuffle the array
        const shuffleArray = (array) => {
            for (let i = array.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [array[i], array[j]] = [array[j], array[i]];
            }
            return array;
        };

        // Shuffle the all_product array within this component
        const shuffled = shuffleArray([...all_product]);
        // Select the first four products
        const relatedProducts = shuffled.slice(0, 4);
        // Set the shuffled products in state
        setShuffledProducts(relatedProducts);
    }, []); // empty dependency array to ensure the effect runs only once on component mount

    return (
        <div className='relatedproducts'>
            <h1>Related Products</h1>
            <hr />
            <div className="relatedproducts-item">
                {shuffledProducts.map((item, i) => (
                    <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price} />
                ))}
            </div>
        </div>
    );
};

export default RelatedProducts;
