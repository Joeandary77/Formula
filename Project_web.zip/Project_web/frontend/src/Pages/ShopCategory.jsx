import React, { useContext } from 'react';
import './CSS/ShopCategory.css';
import { ShopContext } from '../Context/ShopContext';
import dropdown_icon from '../Components/Assets/dropdown_icon.png';
import Item from '../Components/Item/Item';
import food_banner from '../Components/Assets/banner_food.jpeg'
import services_banner from '../Components/Assets/banner_services.jpeg'
import decorations_banner from '../Components/Assets/banner_decorations.jpeg'

const ShopCategory = (props) => {
    const { all_product } = useContext(ShopContext);
    let productsToDisplay = all_product;

    // Filter products based on the banner
    if (props.banner === food_banner) {
        productsToDisplay = all_product.slice(0, 8);
    } else if (props.banner === decorations_banner) {
        productsToDisplay = all_product.filter(item => item.id >= 11 && item.id <= 16);
    } else if (props.banner === services_banner) {
        productsToDisplay = all_product.filter(item => item.id >= 17 && item.id <= 22);
    }

    return (
        <div className='shop-category'>
            <img src={props.banner} alt="" />
            <div className="shopcategory-indexSort">
                <p>
                    <span>
                        Showing 1-{productsToDisplay.length}
                    </span>
                </p>
                <div className="shopcategory-sort">
                    Sort by <img src={dropdown_icon} alt="" />
                </div>
            </div>
            <div className="shopcategory-products">
                {/* Map over the productsToDisplay array */}
                {productsToDisplay.map((item) => (
                    <Item
                        key={item.id}
                        id={item.id}
                        name={item.name}
                        image={item.image}
                        new_price={item.new_price}
                        old_price={item.old_price}
                    />
                ))}
            </div>
            <div className="shopcategory-loadmore">
                Explore More
            </div>
        </div>
    );
};

export default ShopCategory;
