import React from 'react';
import './CSS/ContactPage.css'; // Import CSS file

const ContactPage = () => {
  return (
    <div className="contact-container"> {/* Apply class name to the container */}
      <h1>Contact Us</h1>
      <form>
        <label htmlFor="username">Username:</label>
        <input type="text" id="username" name="username" />

        <label htmlFor="email">Email:</label>
        <input type="email" id="email" name="email" />

        <label htmlFor="feedback">Feedback:</label>
        <textarea id="feedback" name="feedback" rows="4" />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ContactPage;
