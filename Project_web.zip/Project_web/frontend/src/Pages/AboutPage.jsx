import React from 'react';
import './CSS/AboutPage.css';

const AboutPage = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>Here you can find details about our catering formula.</p>
      <p>Our catering formula is designed to exceed your expectations, providing an unparalleled culinary experience for your special events. With meticulous attention to detail and a passion for flavor, our team crafts each dish with the finest ingredients, ensuring a harmonious blend of taste and presentation. Whether you're planning an intimate gathering or a grand celebration, our catering formula offers a diverse selection of menus to suit every palate and occasion. From elegant plated dinners to interactive food stations, we strive to create unforgettable dining experiences that leave a lasting impression on your guests. Let us elevate your event with our signature catering formula, where every dish is a masterpiece and every bite tells a story.</p>
    </div>
  );
};

export default AboutPage;
