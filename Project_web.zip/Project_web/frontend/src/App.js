import './App.css';
import Navbar from './Components/Navbar/Navbar';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ShopCategory from './Pages/ShopCategory';
import Cart from './Pages/Cart';
import LoginSignup from './Pages/LoginSignup';
import Shop from './Pages/Shop';
import Product from './Pages/Product';
import Footer from './Components/Footer/Footer';
import food_banner from './Components/Assets/banner_food.jpeg';
import services_banner from './Components/Assets/banner_services.jpeg';
import decorations_banner from './Components/Assets/banner_decorations.jpeg';
import ContactPage from './Pages/ContactPage'; 
import AboutPage from './Pages/AboutPage'; // Import AboutPage component


function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path='/' element={<Shop />} />
          <Route path='/f&b' element={<ShopCategory banner={food_banner} category="f&b" />} />
          <Route path='/services' element={<ShopCategory banner={services_banner} category="services" />} />
          <Route path='/decorations' element={<ShopCategory banner={decorations_banner} category="decorations" />} />
          <Route path='/product' element={<Product />}>
            <Route path=':productId' element={<Product />} />
          </Route>
          <Route path='/cart' element={<Cart />} />
          <Route path='/login' element={<LoginSignup />} />
          <Route path='/contact' element={<ContactPage />} /> {/* Include ContactPage component */}
          <Route path='/about' element={<AboutPage />} />
        </Routes>

        <Footer />
        
      </BrowserRouter>
    </div>
  );
}

export default App;
