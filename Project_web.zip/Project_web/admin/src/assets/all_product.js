import p1 from './p1.jpg'
import p2 from './p2.jpg'
import p4 from './p4.jpg'
import p5 from './p5.jpg'
import p6 from './p6.jpg'
import p7 from './p7.jpg'
import p8 from './p8.jpg'
import p3 from './p3.jpg'
import p11 from './p11.jpg'
import p12 from './p12.jpg'
import p13 from './p13.jpg'
import p14 from './p14.jpg'
import p15 from './p15.jpg'
import p16 from './p16.jpg'
import p17 from './p17.jpeg'
import p18 from './p18.jpg'
import p19 from './p19.jpg'
import p20 from './p20.jpg'
import p21 from './p21.jpg'
import p22 from './p22.jpg'


let all_product = [
    {
        id:1,
        name:"Fine Dining Experience",
        image: p1,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:2,
        name:"Fine Dining Experience",
        image: p2,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:4,
        name:"Fine Dining Experience",
        image: p4,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:5,
        name:"Fine Dining Experience",
        image: p5,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:6,
        name:"Fine Dining Experience",
        image: p6,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:7,
        name:"Fine Dining Experience",
        image: p7,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:8,
        name:"Fine Dining Experience",
        image: p8,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:3,
        name:"Fine Dining Experience",
        image: p3,
        new_price: 500.00,
        old_price: 850.00,
        category: "FOOD",
    },
    {
        id:11,
        name:"Fine Dining Experience",
        image: p11,
        new_price: 500.00,
        old_price: 850.00,
        category: "Decorations",
    },
    {
        id:12,
        name:"Fine Dining Experience",
        image: p12,
        new_price: 500.00,
        old_price: 850.00,
        category: "Decorations",
    },
    {
        id:13,
        name:"Fine Dining Experience",
        image: p13,
        new_price: 500.00,
        old_price: 850.00,
        category: "Decorations",
    },
    {
        id:14,
        name:"Fine Dining Experience",
        image: p14,
        new_price: 500.00,
        old_price: 850.00,
        category: "Decorations",
    },
    {
        id:15,
        name:"Fine Dining Experience",
        image: p15,
        new_price: 500.00,
        old_price: 850.00,
        category: "Decorations",
    },
    {
        id:16,
        name:"Fine Dining Experience",
        image: p16,
        new_price: 500.00,
        old_price: 850.00,
        category: "Decorations",
    },
    {
        id:17,
        name:"Fine Dining Experience",
        image: p17,
        new_price: 500.00,
        old_price: 850.00,
        category: "SERVICES",
    },
    {
        id:18,
        name:"Fine Dining Experience",
        image: p18,
        new_price: 500.00,
        old_price: 850.00,
        category: "SERVICES",
    },
    {
        id:19,
        name:"Fine Dining Experience",
        image: p19,
        new_price: 500.00,
        old_price: 850.00,
        category: "SERVICES",
    },
    {
        id:20,
        name:"Fine Dining Experience",
        image: p20,
        new_price: 500.00,
        old_price: 850.00,
        category: "SERVICES",
    },
    {
        id:21,
        name:"Fine Dining Experience",
        image: p21,
        new_price: 500.00,
        old_price: 850.00,
        category: "SERVICES",
    },
    {
        id:22,
        name:"Fine Dining Experience",
        image: p22,
        new_price: 500.00,
        old_price: 850.00,
        category: "SERVICES",
    },
    
    
];

export default all_product;


