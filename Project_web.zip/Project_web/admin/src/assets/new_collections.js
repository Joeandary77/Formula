import p1_img from "./Beef&Chicken_food.jpg";
import p2_img from "./pork_food.jpg";
import p3_img from "./see_food.jpg";
import p4_img from "./vegetarian_food.jpg";

let new_collections = [
  {
    id: 10,
    name: "Beef and Chicken buffet dishes",
    image: p1_img,
    new_price: 50.0,
    old_price: 80.5,
  },
  {
    id: 11,
    name: "Pork buffet dishes",
    image: p2_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 12,
    name: "See Food buffet dishes",
    image: p3_img,
    new_price: 60.0,
    old_price: 100.5,
  },
  {
    id: 13,
    name: "Vegetarian buffet dishes",
    image: p4_img,
    new_price: 100.0,
    old_price: 150.0,
  },
];

export default new_collections;
