import img2 from './img2.jpg'
import img3 from './img3.jpg'
import img4 from './img4.jpg'
import img5 from './img5.jpg'

let data_product = [
    {
        id:1,
        name:"Fine Dining Experience",
        image: img2,
        new_price: 500.00,
        old_price: 850.00,
    },
    {
        id:2,
        name:"Engagement offer",
        image: img3,
        new_price: 2500.00,
        old_price: 3500.00,
    },
    {
        id:3,
        name:"Marriage offer",
        image: img4,
        new_price: 8900.00,
        old_price: 12000.00,
    },
    {
        id:4,
        name:"VIP Concert",
        image: img5,
        new_price: 5000.00,
        old_price: 7500.00,
    },
];

export default data_product;


